# 一个简易的时间模块，模仿了PHP的部分扩展，仅支持python3

安装：

```
pip install python-time
```

使用方法：

```
from pytime import pytime

print(pytime.shift('-3 years'))

```

更多的方法可查看源码
